/*
Original Code by Dacal -- Modified Code by Schnedi  // D0 NOT REMOVE THIS LINE //
*/

var Clock = "24h";	       // choose between "12h" or "24h".
var Lang = "ca";	           // choose between "ca", "en", "de" or "fr".

var gps = false; 	       // Requires WidgetWeather2.
var locale = 766537;	       // Yahoo Weather (use it if gps does not work).
var tempUnit = "c";	       // choose between "c" or "f".
var iconSet = "None";   // Do not modify.
var updateInterval = 30;   // in minutes

var UseCityGPS = false;        // If your city is innacurate with Yahoo, you can try to use the GPS localization (if available).
var UseNeighborhood = false;	   // If your city is inaccurate with GPS localization, you can try to use the neighborhood (or state).